#!/bin/bash
date >/var/www/testmacro.txt 
