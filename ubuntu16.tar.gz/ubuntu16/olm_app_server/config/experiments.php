<?php

return [
	"tos1a"	=> [
		"openloop"	=>	["start"],
		"matlab"	=>	["start"]
	]
];