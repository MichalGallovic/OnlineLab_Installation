<?php

return [
	// "command_name"	=>	[
	// 	[
	// 		"name"	=>	"form_name",
	// 		"rules"	=>	"required",
	// 		"title"	=>	"Form title",
	// 		"placeholder"	=>	0.8 //Default form value,
	// 		"type"	=>	"text"
	// 	],
	// 	[
	// 		"name"	=>	"form_name2",
	// 		"rules"	=>	"required",
	// 		"title"	=>	"Form title2",
	// 		"placeholder"	=>	0.8 //Default form value,
	// 		"type"	=>	"textarea"
	// 	],
	//	[
	// 		"name"	=>	"form_name3",
	// 		"rules"	=>	"required",
	// 		"title"	=>	"Form title2",
	// 		"placeholder"	=>	0.8 //Default form value,
	// 		"type"	=>	"checkbox",
	// 		"values"	=>	["Prva","Druha","Tretia"]
	// 	],
	//	[
	// 		"name"	=>	"t_sim",
	// 		"rules"	=>	"required",
	// 		"title"	=>	"Experimant duration",
	// 		"placeholder"	=>	10 //Default form value,
	// 		"type"	=>	"text",
	// 		"meaning" => "experiment_duration" // other options are "sampling_rate", "parent_schema","child_schema"
	// 	]
	// ]
];
