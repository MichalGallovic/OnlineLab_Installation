<?php

namespace WebSocket;
class Exception extends \Exception {}
